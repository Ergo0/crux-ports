#ifndef NVIM_AUCMD_H
#define NVIM_AUCMD_H

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "aucmd.h.generated.h"
#endif

#endif  // NVIM_AUCMD_H

